
class ApiPath{

  static const String baseUrl = "https://cubixsys.com/cubixsys-support/api/";

  static const String sign_up = '${baseUrl}signUp';
  static const String login = '${baseUrl}login';
  static const String forgot_password = '${baseUrl}forgot_password';
}