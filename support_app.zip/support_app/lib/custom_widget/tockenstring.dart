class TokenString {
  static const String userid = 'userid';
  static const String userType = 'userType';
  static const String userEmail = 'userEmail';
  static const String userName = 'userName';
  static const String userProfile = 'userProfile';
  static const String userMobile = 'userMobile';
  static const String productId = 'id';
}
