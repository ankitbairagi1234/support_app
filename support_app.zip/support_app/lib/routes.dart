import 'package:flutter/material.dart';
import 'package:support_app/screens/dashboard/dashboard.dart';
import 'package:support_app/screens/eCatalogue/ECatalogue.dart';
import 'package:support_app/screens/forget/forget.dart';
import 'package:support_app/screens/history/new_tickets.dart';
import 'package:support_app/screens/login/login.dart';
import 'package:support_app/screens/product/product.dart';
import 'package:support_app/screens/product/product_details.dart';
import 'package:support_app/screens/profile/profile.dart';
import 'package:support_app/screens/signup/signup.dart';
import 'package:support_app/screens/stores/stores.dart';
import 'package:support_app/screens/tickets/active_ticket.dart';
import 'package:support_app/screens/tickets/add_issue_ticket.dart';
import 'package:support_app/screens/tickets/add_tickets.dart';
import 'package:support_app/screens/tickets/new_ticket.dart';
import 'package:support_app/screens/tickets/rejected_ticket.dart';
import 'package:support_app/screens/tickets/resolverd_ticket.dart';
import 'package:support_app/service_provider/active_task/active_task.dart';
import 'package:support_app/service_provider/dashbord_service_provider/dashboard.dart';
import 'package:support_app/service_provider/sp_profile/profile_sp.dart';
import 'package:support_app/service_provider/total_task/total_task.dart';
import 'package:support_app/service_provider/total_task_details/total_task_details.dart';

Map<String, WidgetBuilder> routes = {
  Dashboard.routeName:   (context)    => const Dashboard(),
  Product.routeName:     (context)    => const Product(),
  ECatalogue.routeName:  (context)    => const ECatalogue(),
  Stores.routeName:      (context)    => const Stores(),
  History.routeName:     (context)    => const History(),
  Ticket.routeName:      (context)    => const Ticket(),
  Profile.routeName:     (context)    => const Profile(),
  Login.routeName:       (context)    => const Login(),
  Forget.routeName:      (context)    => const Forget(),
  Signup.routeName:      (context)    => const Signup(),
  AddTicket.routeName:   (context)    => const AddTicket(),
  ProductDetails.routeName:   (context)    => const ProductDetails(),
  TicketIssue.routeName:   (context)    => const TicketIssue(),
  ActiveTicket.routeName: (context)   => const ActiveTicket(),
  ResolvedTicket.routeName: (context)   => const ResolvedTicket(),
  RejectedTicket.routeName: (context)   => const RejectedTicket(),
  SpDashboard.routeName : (context)     => const SpDashboard(),
  SpProfile.routeName : (context)     => const SpProfile(),
  ActiveTask.routeName : (context)     => const ActiveTask(),
  TotalTask.routeName : (context)     => const TotalTask(),
  TaskDetails.routeName : (context)     => const TaskDetails(),
};