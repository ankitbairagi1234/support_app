
import 'package:flutter/material.dart';
import 'package:support_app/classes/size_config.dart';

class ForgetBody extends StatefulWidget {
  const ForgetBody({Key? key}) : super(key: key);

  @override
  State<ForgetBody> createState() => _ForgetBodyState();
}

class _ForgetBodyState extends State<ForgetBody> {
  @override
  Widget build(BuildContext context) {
    SizeConfig().init(context);
    return SingleChildScrollView(
      child: Padding(
        padding: const EdgeInsets.only(left: 35, right: 35),
        child: Column(
          children:  [
            Container(
              padding: const EdgeInsets.only(top: 50),
              color: Colors.transparent,
              child: Image.asset('assets/icons/forget_password.png', fit: BoxFit.cover, height: SizeConfig.screenHeight*.3),
            ),
            const SizedBox(height: 30,),
            const Text("Forget Password?", style: TextStyle(fontSize: 25, fontWeight: FontWeight.w400),),
            const SizedBox(height: 15,),
            const Text("Enter Mobile Number associated \nwith your account", textAlign: TextAlign.center, style: TextStyle(color: Color(0xff7B7A7A),  fontSize: 14, fontWeight: FontWeight.w400),),
            const SizedBox(height: 80,),

            TextFormField(
              keyboardType:TextInputType.emailAddress,
              decoration:    InputDecoration(
                enabledBorder: OutlineInputBorder(
                  borderSide: const BorderSide(
                    color: Color(0xffC5C5C5),
                  ),
                  borderRadius: BorderRadius.circular(10.0),
                ),
                focusedBorder: OutlineInputBorder(
                  borderSide: const BorderSide(
                    color:Color(0xffC5C5C5),
                  ),
                  borderRadius: BorderRadius.circular(10.0),
                ),
                hintText: "Enter your email..",
                hintStyle:  const TextStyle(fontWeight: FontWeight.w400, fontSize: 18),
              ),
            ),
            const SizedBox(height: 20,),
            Container(
              height: 60,
              width: SizeConfig.screenWidth*7/8.20,
              decoration:  const BoxDecoration(
                color: Color(0xff376AA9),
                borderRadius:  BorderRadius.all(Radius.circular(15)),
              ),
              child: ElevatedButton(onPressed: (){}, style: ButtonStyle(
                backgroundColor: MaterialStateProperty.all<Color>(const Color(0xff376AA9)),
                shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                    RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(15.0),
                        side: const BorderSide(color: Color(0xff376AA9))
                    )
                ),
              ),  child: const Text("Submit", style: TextStyle(fontSize: 20, fontWeight: FontWeight.w500),),),

            ),
          ],
        ),
      ),
    );
  }
}
