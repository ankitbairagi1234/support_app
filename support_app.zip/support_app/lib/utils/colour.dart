import 'package:flutter/material.dart';

//Colors
final Color primaryColor = Color(0xFF376AA9);
// final Color primaryColor = Color(0xFFA32CC4);
final Color whiteColor = Color(0xFFFFFFFF);
final Color greyColor = Color(0xFFBEBEBE);
final Color greyColor1 = Color(0xFFA4A4A4);
final Color backgroundColor = Color(0xFFF3F3F3);
final Color greyColor3 = Color(0xFF919191);
final Color profileBg = Color(0xFFF6F6F6);
final Color greyColor2 = Color(0xFF747474);
final Color purpleColor = Color(0xFFECE1FF);

//TextStyles
final TextStyle buttonTextStyle = TextStyle(fontSize: 18,fontWeight: FontWeight.bold, color: Colors.white);
